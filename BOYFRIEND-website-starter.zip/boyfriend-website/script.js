const menuToggle = document.getElementById("menuToggle");
const navLinks = document.getElementById("navLinks");
const startButton = document.getElementById("startButton");
const prototypeMessage = document.getElementById("prototypeMessage");

menuToggle.addEventListener("click", () => {
  const isOpen = navLinks.classList.toggle("open");
  menuToggle.setAttribute("aria-expanded", String(isOpen));
  menuToggle.setAttribute("aria-label", isOpen ? "Close navigation" : "Open navigation");
  menuToggle.textContent = isOpen ? "×" : "☰";
});

navLinks.querySelectorAll("a").forEach((link) => {
  link.addEventListener("click", () => {
    navLinks.classList.remove("open");
    menuToggle.setAttribute("aria-expanded", "false");
    menuToggle.textContent = "☰";
  });
});

startButton.addEventListener("click", () => {
  prototypeMessage.textContent =
    "You're at the beginning. Character creation is coming in the next development phase.";
});

document.getElementById("year").textContent = new Date().getFullYear();
